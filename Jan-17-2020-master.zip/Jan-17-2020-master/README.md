# Hello! This is the repository I've created for EPIDEM 2230: Advanced Topics in Epidemiology, meeting January 17, 2020.

A README file should provide basic information about who, what, and when the accompanying files/data package were created. (Sound familiar?) Most often, they're simple .txt files. Github READMEs are a little different in that they're often considered a "welcome mat" to a repository, and provide general context or instructions for using/navigating the files therein. They're written in Markdown, which is very similar to plain text but more functional on the web.

Creator: Helenmary Sheridan, ORCID: https://orcid.org/0000-0002-2328-6465
Date: 20200117
Contact info: helenmary at pitt dot edu
